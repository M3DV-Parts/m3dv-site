export const config = { runtime: 'edge' };

export default async function handler(req) {
  if (req.method !== 'POST') {
    return new Response('Method Not Allowed', { status: 405 });
  }
  try {
    const { to, subject, text, replyTo } = await req.json();
    if(!to) return new Response('Missing to', { status: 400 });

    const RESEND_API_KEY = process.env.RESEND_API_KEY;
    const FROM_EMAIL     = process.env.FROM_EMAIL || 'onboarding@resend.dev';

    const r = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: `M3DV Parts <${FROM_EMAIL}>`,
        to: [to],
        subject,
        text,
        reply_to: replyTo || 'info@m3dv.it'
      })
    });
    const body = await r.text();
    return new Response(body, { status: r.ok ? 200 : 500 });
  } catch (e) {
    return new Response('Server error', { status: 500 });
  }
}
